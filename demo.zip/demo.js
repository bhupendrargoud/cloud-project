data=[
 
   
    
     
      {
        "Name" : "The Alchemist",
        "Cost" : "₹320",
        "Publisher" : "Harper; Later Printing Edition",
        "Author" : "Paulo Coelho",
        "Description" : "This book is about an Andalusian shepherd boy named Santiago who travels from his homeland in Spain to the Egyptian desert in serach of a treasure burried in pyramids."
      },
      
      {
        "Name" : "400 Days",
        "Cost" : "₹155",
        "Publisher" : "Westland",
        "Author" : "Chetan Bhagat",
        "Description" : "A mystery and Romance story like no other."
      },
     
      {
        "Name" : "1984",
        "Cost" : "₹199",
        "Publisher" : "Fingerprint Publishing", 
        "Author" : "George Orwell",
        "Description" : "1984 is a brilliant, and more importantly, a timeless satirical attack on the social and political structures of the world." 
      }
      
      
     ]

     function bk_data()
     {
        table="<table align=center><tr><th>book_NAME</th><th>book_NAME</th><th>cost</th><th>auth</th><th>pub</th><th>des</th></tr>";
        for (var i = 0; i < data.length; i++) {
            table+="<tr><td>"+"<img src='./Images/"+data[i].Name+".png' alt='no img'>"+"</td><td>"+data[i].Name+"</td><td>"+data[i].Cost+"</td><td>"+data[i].Author+"</td><td>"+data[i].Publisher+"</td><td>"+data[i].Description+"</td></tr>";

        }
        table+="</table>"
    
        document.getElementById("b_data").innerHTML=table;
     }