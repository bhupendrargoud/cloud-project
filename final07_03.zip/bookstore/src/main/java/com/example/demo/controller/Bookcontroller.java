package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Book;

import com.example.demo.repository.Bookrepository;


@CrossOrigin(origins="*")
@RestController
@RequestMapping("/book")
public class Bookcontroller {
  
	 @Autowired
	Bookrepository bookRepository;
	 
	  //insert a book
	  @PostMapping("/save")
	 public ResponseEntity<Book> createBook(@RequestBody Book book)
	 {
		 Book _book = bookRepository.save(new Book(book.getName(),book.getCost(),book.getPublisher(),book.getAuthor(),book.getDescription()));
		 return new ResponseEntity<>(_book,HttpStatus.CREATED);
	 }
	  
	  // get information 
	  @GetMapping("/get_all_books")
	  public ResponseEntity<List<Book>> getAllBooks()
	  {
		  List books = new ArrayList<Book>();
		  bookRepository.findAll().forEach(books::add);
		  return new ResponseEntity<>(books,HttpStatus.OK);
		  
	  }
	   //fetch user by id
	  @GetMapping("/get_books_by_name/{name}")
	  public ResponseEntity<Book> getBookById(@PathVariable("name") String name)
	  {
		  Optional<Book> bookData=bookRepository.findById(name);
		  if(bookData.isPresent())
		  {
			  return new ResponseEntity<>(bookData.get(),HttpStatus.OK);
		  }
		  else
		  {
			  return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		  }
	  }
	 
		//update book by name
		@PutMapping("/update_nid/{id}")
		public ResponseEntity<Book> updateId(@PathVariable("id") String id,@RequestBody Book book)
		{
		Optional<Book> bookData=bookRepository.findById(id);
		if(bookData.isPresent())
		{
		Book _book=bookData.get();
		_book.setName(book.getName());
		_book.setCost(book.getCost());
		_book.setPublisher(book.getPublisher());
		_book.setAuthor(book.getAuthor());
		_book.setDescription(book.getDescription());
		
		return new ResponseEntity<>(bookData.get(),HttpStatus.OK);
		}
		else
		{
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		}
		
		//delete by id
		@DeleteMapping("/delete_name/{name}")
		public ResponseEntity<HttpStatus> deleteId(@PathVariable("name") String name)
		{
		bookRepository.deleteById(name);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		
		//delete all books
		@DeleteMapping("/delete_all")
				public ResponseEntity<HttpStatus> deleteAll()
				{
				bookRepository.deleteAll();
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
		
	  }
	  
	  
	  
	  
	  
	  
	  
	  
	

