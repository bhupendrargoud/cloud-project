package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

 @Entity
 @Table(name="Book")
 
public class Book {
	 
	@Id
  private String name;
	
	@Column(name="cost")
  private String cost;
	
	@Column(name="publisher")
  private String publisher;
	
	@Column(name="author")
  private String author;
	
	@Column(name="description")
  private String description;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Book(String name, String cost, String publisher, String author, String description) {
		
		this.name = name;
		this.cost = cost;
		this.publisher = publisher;
		this.author = author;
		this.description = description;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Book [name=" + name + ", cost=" + cost + ", publisher=" + publisher + ", author=" + author
				+ ", description=" + description + ", getName()=" + getName() + ", getCost()=" + getCost()
				+ ", getPublisher()=" + getPublisher() + ", getAuthor()=" + getAuthor() + ", getDescription()="
				+ getDescription() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	
}
