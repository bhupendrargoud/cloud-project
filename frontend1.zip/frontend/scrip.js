
//shopownerlogin

           

            function sign_inA() {

                console.log("sign in admin");

                var ua=document.getElementById("uid").value ;
              var pa=document.getElementById("pswd").value ;
               
             //  var ua="admin";
             //  var pa="a@123";
            
                
                if(ua=="admin" && pa=="a@123")
                {
                    var url="shopowner.html";
                window.location.replace(url);
              
                console.log("admin login");
                }else
                {
                    alert("Invalid data XXX")
                }
            }

///////////////////////////////////////////////////////////////////////////////////////////////////.
 

                    function gRN()
                    {
                        console.log("random number")
                        var rand = Math.floor(Math.random() * 1000000) + 1;
                    return rand;
                    }


//-----------------------------------------------------------------------------------------------------------------
////////////////////////////////////////////////////////////////////////////////////////////////

 //users




        function sign_in(){

            console.log("sign in");



                userid=document.getElementById("uid").value.toUpperCase();

                userp=document.getElementById("pswd").value;



                if(verfy_mob(userid))

                {

                url="http://localhost:8080/user/get_user_num/"+userid;

                gt(url);

         }

               else if(verfy_eml(userid))

                {

                    url="http://localhost:8080/user/get_user_email/"+userid;

                    gt(url);

                }

                else{

                    url="http://localhost:8080/user/get_user_by_uid/"+userid; 

                    gt(url);

                }





                function gt(url) {

                    

                

                let fr=fetch(url,{method: 'GET'})

                fr.then(function (response) {

                return response.json();

            })

            .then(data => {

                console.log("success")

                console.log(data.paswd);

                append(data);    

            })

            .catch(function (err) {

            console.log('error: ' + err);

            alert("invalid User ID");

            });



        }




            function append(data) 

                {

                    console.log(data.paswd);

                    if (userp==data.paswd) 

                    {

                        console.log("user login sucessfull");

                        alert("login sucessful")

                        window.location.replace("visitor.html");

                    }

                    else {

                    alert("invalid password");

                    }

                

                

                }




        }



     //-----------------------------------------------------------------------------------




            function sign_up(){



                console.log("sign up");

                var us = document.getElementById("suid").value.toUpperCase();

                var dob = document.getElementById("sdob").value;

                var dobi=dob.toString();



                var nam = document.getElementById("sfn").value.toUpperCase();

                var mob= document.getElementById("smbn").value;

                var em= document.getElementById("sem").value.toUpperCase();

                var ps = document.getElementById("spswd").value;

               var con=false;

               var con1=false;

               if(verfy_mob(mob))

               {

                   con=true;

               }

               else

               {

                   alert("Enter a valid mobile number")

               }



               if(verfy_eml(em))

               {

                   con1=true;

               }

               else

               {

                   alert("Enter a valid Email ID")

               }



                



                var data = 

                    {

                        "usid":us,

                    "dob":dobi,

                    "name":nam,

                    "pnum":mob,

                    "email":em,

                    "paswd":ps

                        

                    }

                

            




                let options = {

                    method:'POST',

                    headers:{

                        'Content-Type':'application/json'

                    },

                    body:JSON.stringify(data)

                }

            

                if (con && con1) {

                    

                

                let fres = fetch("http://localhost:8080/user/save",options);

                fres.then(res => res.json()).then(d => {

                    console.log("success"+ d);

                   

                    alert("registered sucessfully");

                })



                }

               

                

            }





    //-------------------------------------------------------------------------------------------------

                
